from odoo import models, fields, api

class KegiatanSiswa(models.Model):
    _name = "kegiatan.siswa"
    _description = "Student Course Details"
    _inherit = "mail.thread"
    _rec_name = 'student_id'

    student_id = fields.Many2one('op.student', 'Student', ondelete="cascade", tracking=True)
    nama_kegiatan = fields.Many2one('Kegiatan')
    deskripsi = fields.Text('Deskripsi')

class MasterKegiatan(models.Model):
    _name = "master.kegiatan"
    _description = 'Master Kegiatan'

    nama_kegiatan = fields.Char('Nama Kegiatan')